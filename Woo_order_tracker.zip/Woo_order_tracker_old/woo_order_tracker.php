<?php
/**
 * Plugin Name: Woo Order Tracker
 * Description: A WooCommerce plugin to track orders and send webhooks.
 * Version: 1.0
 * Author: jay
 * Text Domain: woo-order-tracker
 * Domain Path: /languages/
 */

// Hook for adding admin menus
add_action('admin_menu', 'woo_order_tracker_menu');

// Action hook to initialize the plugin
add_action('admin_init', 'woo_order_tracker_settings_init');

// Localization setup
add_action('init', 'woo_order_tracker_load_textdomain');

// Register the custom REST API endpoint
add_action('rest_api_init', function () {
    register_rest_route('woo-order-tracker/v1', '/webhook/', array(
        'methods' => 'POST',
        'callback' => 'handle_woo_order_tracker_webhook',
        'permission_callback' => '__return_true', // Consider using a proper permission callback for production
    ));
});

function woo_order_tracker_load_textdomain() {
    load_plugin_textdomain('woo-order-tracker', false, dirname(plugin_basename(__FILE__)) . '/languages/');
}

// Function to add a menu item for the plugin settings
function woo_order_tracker_menu() {
    add_menu_page(
        __('Woo Order Tracker Settings', 'woo-order-tracker'), // Page title
        'Woo Order Tracker', // Menu title
        'manage_options', // Capability
        'woo-order-tracker', // Menu slug
        'woo_order_tracker_settings_page', // Function to display the settings page
        null, // Icon URL
        20 // Position
    );
}

// Function to register settings
function woo_order_tracker_settings_init() {
    // Register a new setting for "Woo Order Tracker" page
    register_setting('woo_order_tracker', 'woo_order_tracker_settings','woo_order_tracker_sanitize_settings');

    // Add a new section to a settings page
    add_settings_section(
        'woo_order_tracker_section',
        __('Order Tracking Settings', 'woo-order-tracker'),
        'woo_order_tracker_section_cb',
        'woo_order_tracker'
    );

    // Add a new field to a section of a settings page
    add_settings_field(
        'woo_order_tracker_field_pill', // As of WP 4.6 this value is used only internally
        __('Enable Tracking', 'woo-order_tracker'), // Field title
        'woo_order_tracker_field_pill_cb', // Callback function
        'woo_order_tracker', // Page
        'woo_order_tracker_section' // Section
    );

    // Add a new field for Destination URL webhook
    add_settings_field(
        'woo_order_tracker_destination_url', // Field ID
        __('Destination URL Webhook', 'woo-order_tracker'), // Field title
        'woo_order_tracker_destination_url_cb', // Callback function
        'woo_order_tracker', // Page
        'woo_order_tracker_section' // Section
    );
}

function woo_order_tracker_sanitize_settings($options) {
    // Sanitize the checkbox input
    if (!isset($options['enabled'])) {
        $options['enabled'] = '0';
    } else {
        $options['enabled'] = '1';
    }
    
    // Sanitize the URL
    if (isset($options['destination_url'])) {
        $options['destination_url'] = esc_url_raw($options['destination_url']);
    }
    
    return $options;
}


// Callback function for section description
function woo_order_tracker_section_cb() {
    echo '<p>' . __('Set your preferences for the Woo Order Tracker.', 'woo-order-tracker') . '</p>';
}

// Callback function for the enable/disable tracking checkbox
function woo_order_tracker_field_pill_cb() {
    $options = get_option('woo_order_tracker_settings');
    $checked = isset($options['enabled']) ? $options['enabled'] : '0';
    ?>
    <input type='checkbox' name='woo_order_tracker_settings[enabled]' <?php checked($options['enabled'], 1); ?> value='1'>
    <?php
}

// Callback function for the destination URL webhook input
function woo_order_tracker_destination_url_cb() {
    $options = get_option('woo_order_tracker_settings');
    ?>
    <input type='text' name='woo_order_tracker_settings[destination_url]' value='<?php echo $options['destination_url']; ?>'>
    <?php
}

// -----------------------------------------------------------------------------

// Callback function to render the settings page
function woo_order_tracker_settings_page() {
    ?>
    <div class="wrap">
        <h1><?php echo esc_html(get_admin_page_title()); ?></h1>
        <form action='options.php' method='post'>

            <?php
            settings_fields('woo_order_tracker');
            do_settings_sections('woo_order_tracker');
            submit_button(__('Save Settings', 'woo-order-tracker'));
            ?>

        </form>
    </div>
    <?php
}
// -----------------------------------------------------------------------------



// ----- Action hooks for various WooCommerce order events ----- //



// ************* 1 **************


// On checkout Update
add_action('woocommerce_checkout_update_order_meta', 'woo_order_tracker_send_webhook_on_checkout_update');
function woo_order_tracker_send_webhook_on_checkout_update($order_id) {
    woo_order_tracker_send_webhook($order_id, 'woocommerce_checkout_update_order_meta');
}


// ************* 2 **************



// Once the Order Status has been modified
add_action('woocommerce_order_status_changed', 'woo_order_tracker_send_webhook_on_order_status_change');
function woo_order_tracker_send_webhook_on_order_status_change($order_id) {
    $order = wc_get_order($order_id);
    if($order->get_status() == "completed") return;
    woo_order_tracker_send_webhook($order_id, 'woocommerce_order_status_changed');
}



// ************* 3 **************



// when the order has been canceled
add_action('woocommerce_cancelled_order', 'woo_order_tracker_send_webhook_on_order_cancel');
function woo_order_tracker_send_webhook_on_order_cancel($order_id) {
    woo_order_tracker_send_webhook($order_id, 'woocommerce_cancelled_order');
}



// ************* 4 ************** 



// when the order move to trash
add_action('woocommerce_trash_order', 'woo_order_tracker_send_webhook_on_order_trash');
function woo_order_tracker_send_webhook_on_order_trash($order_id) {
    woo_order_tracker_send_webhook($order_id, 'woocommerce_trash_order');
}



// ************* 5 **************



// When the order has notes
add_action('woocommerce_order_note_added', 'woo_order_tracker_send_webhook_on_order_note_added',10,2);
function woo_order_tracker_send_webhook_on_order_note_added($comment_id,$order_id) {
    $comment_obj   = get_comment( $comment_id );
    $customer_note = $comment_obj->comment_content;
    $options = get_option('woo_order_tracker_settings');
    if (!$options['enabled']) return;
    $order = wc_get_order($order_id);
    if(!$order) return;

    $order_data = array(
        'order_id' => $order->get_id(),
        'order_note' => $customer_note,
    );
    $destination_url = $options['destination_url'];
    if (!$destination_url) return; // Exit if no destination URL is set

    // Encode the data as JSON
    $json_payload = wp_json_encode($order_data);

    // The destination URL from the settings
    $destination_url = esc_url_raw($options['destination_url']);

    // Set up the arguments for the POST request
    $args = array(
        'body'        => $json_payload,
        'headers'     => array(
            'Content-Type' => 'application/json',
        ),
        'timeout'     => 45,
        'redirection' => 5,
        'blocking'    => true,
        'httpversion' => '1.0',
        'sslverify'   => false, // Set to true in production for security
        'data_format' => 'body',
    );

    // Send the POST request
    $response = wp_remote_post($destination_url, $args);
    // Error handling
    if (is_wp_error($response)) {
        error_log('Woo Order Tracker webhook error: ' . $response->get_error_message());
    } else {
        $response_code = wp_remote_retrieve_response_code($response);
        error_log($response_code);
        if ($response_code != 200) {
        error_log('Woo Order Tracker webhook error: Unexpected response code ' . $response_code);
        }
    }   
}


// ************* 6 **************



//When the order status has been set to complete
add_action('woocommerce_order_status_completed', 'woo_order_tracker_send_webhook_on_order_complete');
function woo_order_tracker_send_webhook_on_order_complete($order_id) {
    
    woo_order_tracker_send_webhook($order_id, 'woocommerce_order_status_completed');
}

function get_last_updated_order_note( $order_id ) {
    global $wpdb;

    $table_prefixed = $wpdb->prefix . 'comments';
    $result = $wpdb->get_row( $wpdb->prepare( "
        SELECT *
        FROM $table_prefixed
        WHERE `comment_post_ID` = %d
        AND `comment_type` = 'order_note'
        ORDER BY `comment_date` DESC
        LIMIT 1
    ", $order_id ) );

    if ( $result ) {
        $order_note = array(
            'note_id'      => $result->comment_ID,
            'note_date'    => $result->comment_date,
            'note_author'  => $result->comment_author,
            'note_content' => $result->comment_content,
        );

        return $order_note;
    } else {
        return false; // No order note found
    }
}

// -----------------------------------------------------------------------------


// Sending to webhook via POST in JSON format with the order details to a Destination URL
function woo_order_tracker_send_webhook($order_id) {
    // First, we check if the tracker is enable or not
    $options = get_option('woo_order_tracker_settings');
    if (!$options['enabled']) return; // Exit if tracking is not enabled

    // Get the order object
    $order = wc_get_order($order_id);
    if(!$order) return; // Exit if the order cannot be retrieved
    $last_order_note = get_last_updated_order_note($order_id);
    

    // We have selected a few key pieces of data, including:
        //The order number, order total, currency type, current order status, and the most recent billing email.
    $order_data = array(
        'order_id'       => $order->get_id(),
        'order_total'    => $order->get_total(),
        'order_currency' => $order->get_currency(),
        'order_status'   => $order->get_status(),
        'billing_email'  => $order->get_billing_email(),
        'last_order_note' => $order->get_customer_note(),
    );

    //second, we check if the  destination URL is set or not
    $destination_url = $options['destination_url'];
    if (!$destination_url) return; // Exit if no destination URL is set


    // Encode the data as JSON
    $json_payload = wp_json_encode($order_data);

    // The destination URL from the settings
    $destination_url = esc_url_raw($options['destination_url']);

    // Set up the arguments for the POST request
    $args = array(
        'body'        => $json_payload,
        'headers'     => array(
            'Content-Type' => 'application/json',
        ),
        'timeout'     => 45,
        'redirection' => 5,
        'blocking'    => true,
        'httpversion' => '1.0',
        'sslverify'   => false, // Set to true in production for security
        'data_format' => 'body',
    );

    // Send the POST request
    $response = wp_remote_post($destination_url, $args);
    // Error handling
    if (is_wp_error($response)) {
        error_log('Woo Order Tracker webhook error: ' . $response->get_error_message());
    } else {
        $response_code = wp_remote_retrieve_response_code($response);
        error_log($response_code);
        if ($response_code != 200) {
        error_log('Woo Order Tracker webhook error: Unexpected response code ' . $response_code);
    }
}
}

// Function to handle form submission and save settings
function woo_order_tracker_save_settings() {
    if (isset($_POST['submit']) && $_POST['submit'] == 'Save Settings') {
        // Sanitize the input
        $enabled = isset($_POST['woo_order_tracker_settings']['enabled']) ? '1' : '0';
        $destination_url = isset($_POST['woo_order_tracker_settings']['destination_url']) ? esc_url_raw($_POST['woo_order_tracker_settings']['destination_url']) : '';
        // Save the settings
        update_option('woo_order_tracker_settings', array(
            'enabled' => $enabled,
            'destination_url' => $destination_url,
        ));
    }
}
add_action('admin_init', 'woo_order_tracker_save_settings');